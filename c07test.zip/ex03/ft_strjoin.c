/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strjoin.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/01 20:23:44 by wngui             #+#    #+#             */
/*   Updated: 2023/07/01 20:23:59 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

// Function to concatenate an array of strings with a separator
char *ft_strjoin(int size, char **strs, char *sep)
{
    int total_length = 0;
    for (int i = 0; i < size; i++)
    {
        total_length += strlen(strs[i]);
        if (i != size - 1)
            total_length += strlen(sep);
    }

    // Allocate memory for the resulting string
    char *result = malloc((total_length + 1) * sizeof(char));
    if (!result)
        return NULL;

    int index = 0;
    for (int i = 0; i < size; i++)
    {
        // Copy each string into the result
        strcpy(result + index, strs[i]);
        index += strlen(strs[i]);

        if (i != size - 1)
        {
            // Copy the separator into the result
            strcpy(result + index, sep);
            index += strlen(sep);
        }
    }

    return result;
}

int main(void)
{
    char *strs[] = {"Hello", "world", "!", "This", "is", "a", "test"};
    char *sep = "-";
    char *result;

    int size = sizeof(strs) / sizeof(strs[0]);

    // Call the ft_strjoin function to concatenate the strings
    result = ft_strjoin(size, strs, sep);

    if (result == NULL)
    {
        printf("String concatenation failed.\n");
        return 1;
    }

    printf("Concatenated string: %s\n", result);

    free(result);

    return 0;
}

