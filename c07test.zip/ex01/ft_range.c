/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_range.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/01 20:16:56 by wngui             #+#    #+#             */
/*   Updated: 2023/07/01 20:17:03 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <stdio.h>

// Function to generate an array of integers within a given range
int *ft_range(int min, int max)
{
    int range;
    int *buffer;
    int *d;

    if (min >= max)
        return NULL;

    range = max - min;

    // Allocate memory for the buffer array
    buffer = malloc(range * sizeof(int));
    if (!buffer)
        return NULL;

    d = buffer;
    while (min < max)
        *d++ = min++;

    return buffer;
}

int main(void)
{
    int min = 5;
    int max = 10;

    // Call the ft_range function to generate the range of integers
    int *tab = ft_range(min, max);

    if (tab == NULL)
    {
        printf("Invalid range: min >= max\n");
        return 1;
    }

    int size = max - min;

    printf("Range: ");
    for (int i = 0; i < size; i++)
        printf("%d, ", tab[i]);
    printf("\n");

    // Free the dynamically allocated memory
    free(tab);

    return 0;
}

