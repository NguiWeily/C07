/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_range.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/01 20:20:34 by wngui             #+#    #+#             */
/*   Updated: 2023/07/01 20:20:49 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <stdio.h>

// Function to generate an array of integers within a given range
int ft_ultimate_range(int **range, int min, int max)
{
    int size;
    int *buffer;
    int *d;

    if (min >= max)
    {
        // Set the range pointer to NULL and return 0 if the range is invalid
        *range = NULL;
        return 0;
    }

    size = max - min;

    // Allocate memory for the buffer array
    buffer = malloc(size * sizeof(int));
    if (!buffer)
        return -1; // Return -1 to indicate memory allocation failure

    d = buffer;
    while (min < max)
        *d++ = min++;

    *range = buffer; // Assign the buffer pointer to the range pointer

    return size;
}

int main(void)
{
    int *tab;
    int size;
    int i;

    int min = 5;
    int max = 10;

    // Call the ft_ultimate_range function to generate the range of integers
    size = ft_ultimate_range(&tab, min, max);

    if (size == -1)
    {
        printf("Memory allocation failed.\n");
        return 0;
    }
    else if (size == 0)
    {
        printf("Invalid range.\n");
        return 0;
    }

    // Print the elements of the range
    for (i = 0; i < size; i++)
    {
        printf("%d ", tab[i]);
    }
    printf("\n");

    // Free the dynamically allocated memory
    free(tab);

    return 0;
}

