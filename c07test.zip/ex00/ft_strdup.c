/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strdup.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/01 20:14:44 by wngui             #+#    #+#             */
/*   Updated: 2023/07/02 09:41:55 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <stdio.h>

// Function to calculate the length of a string
int ft_str_length(char *str)
{
    int index;

    index = 0;
    while (str[index])
        index++;
    return (index);
}

// Function to duplicate a string using dynamic memory allocation
char *ft_strdup(char *src)
{
    int index;
    char *dest;
    char *d;

    index = 0;
    // Allocate memory for the destination string
    d = ((dest = (char *)malloc(ft_str_length(src) * sizeof(char) + 1)));
    if (!d)
    {
        // Return null if memory allocation fails
        return (0);
    }
    while (src[index])
    {
        // Copy characters from the source string to the destination string
        dest[index] = src[index];
        index++;
    }
    dest[index] = '\0'; // Add null-terminator to the end of the destination string
    return (dest);
}

int main(void)
{
    char *str;
    char *allocated;

    str = "Hello World with malloc()";
    printf("original  : base  : $%s$ @ %p\n", str, str);

    // Using strdup() function from the standard library
    allocated = ft_strdup(str);
    printf("copied    : alloc : $%s$ @ %p\n", allocated, allocated);

    // Using the custom ft_strdup() function
    allocated = ft_strdup(str);
    printf("ft_copied : alloc : $%s$ @ %p\n", allocated, allocated);
}

