/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strjoin.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/01 20:23:44 by wngui             #+#    #+#             */
/*   Updated: 2023/07/02 15:30:32 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <stdio.h>

int	ft_strlen(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
		i++;
	return (i);
}

int	ft_tstrlen(int size, char **strs, char *sep)
{
	int	total;
	int	i;

	i = 0;
	total = 0;
	while (i < size)
	{
		total += ft_strlen(strs[i]);
		total += ft_strlen(sep);
		i++;
	}
	total -= ft_strlen(sep);
	return (total);
}

void	ft_char_memcpy(char *dest, char *src, unsigned int size)
{
	unsigned int	i;

	i = 0;
	while (i < size)
	{
		dest[i] = src[i];
		i++;
	}
}

void	ft_tstrcpy(char **res, int size, char **strs, char *sep)
{
	int	offset;
	int	i;

	offset = 0;
	i = 0;
	while (i < size)
	{
		ft_char_memcpy(*res + offset, strs[i], ft_strlen(strs[i]));
		offset += ft_strlen(strs[i]);
		if (i != size - 1)
		{
			ft_char_memcpy(*res + offset, sep, ft_strlen(sep));
			offset += ft_strlen(sep);
		}
		i++;
	}
	ft_char_memcpy(*res + offset, "", 1);
}

char	*ft_strjoin(int size, char **strs, char *sep)
{
	char	*res;

	if (size == 0)
	{
		res = malloc(1 * sizeof(char));
		res[0] = '\0';
		return (res);
	}
	res = (char *) malloc((ft_tstrlen(size, strs, sep) + 1) * sizeof(int));
	if (res == NULL)
		return (NULL);
	ft_tstrcpy(&res, size, strs, sep);
	return (res);
}
/*
int main(void)
{
	char *strs[] = {"Hello", "world", "!", "This", "is", "a", "test"};
	char *sep = "-";
	char *result;

	int size = sizeof(strs) / sizeof(strs[0]);

	result = ft_strjoin(size, strs, sep);

	if (result == NULL)
	{
		printf("String concatenation failed.\n");
		return 0;
	}

	printf("Concatenated string: %s\n", result);

	free(result);

	return 0;
}*/
