/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_range.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/01 20:20:34 by wngui             #+#    #+#             */
/*   Updated: 2023/07/01 20:20:49 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <stdio.h>

int	ft_ultimate_range(int **range, int min, int max)
{
	int	size;
	int	*buffer;
	int	*d;

	if (min >= max)
	{
		*range = NULL;
		return (0);
	}
	size = max - min;
	buffer = malloc(size * sizeof(int));
	if (!buffer)
		return (-1);
	d = buffer;
	while (min < max)
		*d++ = min++;
	*range = buffer;
	return (size);
}
/*
int main(void)
{
	int *tab;
	int size;
	int i;

	int min = 5;
	int max = 10;

	size = ft_ultimate_range(&tab, min, max);
	if (size == -1)
	{
		printf("Memory allocation failed.\n");
		return 0;
	}
	else if (size == 0)
	{
		printf("Invalid range.\n");
		return 0;
	}

	for (i = 0; i < size; i++)
	{
		printf("%d ", tab[i]);
	}
	printf("\n");

	free(tab);

	return 0;
}*/
